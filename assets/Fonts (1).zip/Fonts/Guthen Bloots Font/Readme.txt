UPDATE MARCH 2020: Guthen Bloots Slant Version (otf,ttf,woff/woff2)

Hello There.

Thank for purchasing and using Guthen Bloots Font.

We really hope, you enjoy this font.

If there is a problem, question, or anything about our fonts, please sent us an email to azetmedia86@gmail.com

Thank You

Azetype Studio.